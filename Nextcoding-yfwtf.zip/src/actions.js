import { HttpError } from 'wasp/server'

export const createService = async ({ name, description }, context) => {
  if (!context.user) { throw new HttpError(401) };
  const newService = await context.entities.Service.create({
    data: { name, description, userId: context.user.id }
  });
  return newService;
}

export const updateService = async ({ id, name, description }, context) => {
  if (!context.user) { throw new HttpError(401) };

  const service = await context.entities.Service.findUnique({
    where: { id }
  });
  if (!service || service.userId !== context.user.id) { throw new HttpError(403) };

  return context.entities.Service.update({
    where: { id },
    data: { name, description }
  });
}
