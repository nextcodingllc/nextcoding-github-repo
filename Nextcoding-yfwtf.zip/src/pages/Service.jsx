import React from 'react';
import { useParams } from 'wasp/client/router';
import { useQuery, useAction, getServiceDetails, updateService } from 'wasp/client/operations';

const ServicePage = () => {
  const { serviceId } = useParams();
  const { data: service, isLoading, error } = useQuery(getServiceDetails, { id: parseInt(serviceId) });
  const updateServiceFn = useAction(updateService);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleUpdateService = (name, description) => {
    updateServiceFn({ id: service.id, name, description });
  };

  return (
    <div className="p-4 bg-slate-50 rounded-lg">
      <h1 className="text-2xl font-bold mb-4">{service.name}</h1>
      <p className="mb-4">{service.description}</p>
      <button
        onClick={() => handleUpdateService('New Name', 'Updated description')}
        className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
      >
        Update Service
      </button>
    </div>
  );
};

export default ServicePage;
