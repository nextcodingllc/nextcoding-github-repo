import React from 'react';
import { useQuery } from 'wasp/client/operations';
import { getServices } from 'wasp/client/operations';
import { Link } from 'wasp/client/router';

const HomePage = () => {
  const { data: services, isLoading, error } = useQuery(getServices);

  if (isLoading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div className="p-8 bg-gray-50 min-h-screen">
      <h1 className="text-4xl font-bold text-center mb-8">Welcome to Nextcoding IT Services</h1>
      <div className="flex justify-end mb-4">
        <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Translate to Spanish</button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {services.map((service) => (
          <div key={service.id} className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-2xl font-bold mb-2">{service.name}</h2>
            <p className="text-gray-700">{service.description}</p>
            <Link to={`/service/${service.id}`} className="text-blue-500 hover:underline mt-4 inline-block">View Details</Link>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HomePage;
