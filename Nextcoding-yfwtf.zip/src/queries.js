import { HttpError } from 'wasp/server'

export const getServices = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  return context.entities.Service.findMany({
    where: {
      userId: context.user.id
    }
  });
}

export const getServiceDetails = async ({ id }, context) => {
  if (!context.user) { throw new HttpError(401) }

  const service = await context.entities.Service.findUnique({
    where: { id },
    select: {
      id: true,
      name: true,
      description: true,
      userId: true
    }
  });

  if (!service) throw new HttpError(404, 'No service with id ' + id);
  if (service.userId !== context.user.id) throw new HttpError(403, 'Service does not belong to the user.');

  return service;
}
